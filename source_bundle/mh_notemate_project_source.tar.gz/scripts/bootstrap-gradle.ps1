$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$version = '8.13'
$homeDir = if ($env:GRADLE_USER_HOME) { $env:GRADLE_USER_HOME } else { Join-Path $env:USERPROFILE '.gradle' }
$cache = Join-Path $homeDir 'mh-notemate-bootstrap'
$exe = Join-Path $cache "gradle-$version\bin\gradle.bat"
if (!(Test-Path $exe)) {
    New-Item -ItemType Directory -Path $cache -Force | Out-Null
    $archive = Join-Path $cache 'gradle.zip'
    Write-Host "Downloading Gradle $version (first run only)..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $archive
    Expand-Archive -Path $archive -DestinationPath $cache -Force
    Remove-Item $archive
}
Set-Location $project
& $exe @args
exit $LASTEXITCODE
